# Farias Diogle Soluções Elétricas

Site institucional da **Farias Soluções Elétricas — Eletricista Predial e Residencial**.

## Publicação no GitHub Pages

1. Crie um repositório chamado `farias-diogle-solucoes-eletricas`.
2. Envie o arquivo `index.html` para a raiz do repositório.
3. No GitHub, abra **Settings → Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**.
5. Escolha a branch `main` e a pasta `/ (root)`.
6. Salve e aguarde a publicação.

O site não depende de frameworks ou de build: o `index.html` pode ser publicado diretamente pelo GitHub Pages.
